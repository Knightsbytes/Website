#step 1
new_var = "some text"
print(new_var)

#step 2
print(new_var + "and more text")

#step 3
print(f"{new_var} and more text")

#step 4 for those who are done
for i in new_var:
    print(i)

#step 4b      vselected partv
print(new_var[0:len(new_var)])

#print only one letter (replace 0 with which letter you would like to print. The order is 012345...)
print(new_var[0])
